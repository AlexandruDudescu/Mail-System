import javax.swing.JTextArea;

/**
 * Storage support for system to save voice message
 * @author Wei Li
 * @date January 14, 2017
 */
public class Mailbox {
	private String extension; // id
	private Messages messages; // messages stored in this mailbox
	
	Mailbox(String extension) {
		this.extension = extension;
		messages = new Messages();
	}
	
	/**
	 * Save a message
	 * @param text message to be saved
	 */
	public void saveMessage(String text) {
		messages.saveMessage(text);
	}
	
	public String getExtension() { 
		return extension;
	}
	
	public void playMessages(JTextArea speaker) {
		messages.playMessages(speaker);
	}
}
