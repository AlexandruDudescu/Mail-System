import java.util.ArrayList;

import javax.swing.JTextArea;

/**
 * Storage support for system to have multiple mailboxes
 * @author Wei Li
 * @date January 14, 2017
 */
public class Mailboxes {
	private ArrayList<Mailbox> mailboxes;
	int current = -1;  // current mailbox index
	
	Mailboxes() {
		mailboxes = new ArrayList<Mailbox>();
	}
	
	/**
	 * The mailbox that matches the extension is the current mailbox
	 * @param extension to be matched
	 * @return true if match; false otherwise
	 */
	public boolean findCurrentMailBox(String extension) {
		int index;
		for (index=0; index<mailboxes.size(); index++) {
			if(mailboxes.get(index).getExtension().equals(extension)) {
				current = index;
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Check if a mailbox exists in the array
	 * @param mailbox to be checked
	 * @return true if in; false otherwise;
	 */
	private boolean inMailBoxes(Mailbox mailbox) {
		for(Mailbox mb: mailboxes) {
			if(mb.getExtension().equals(mailbox.getExtension()))
				return true;
		}
		return false;
	}
	
	/**
	 * Add a mailbox
	 * @param mailbox to be added
	 * @precondition mailbox not in array
	 */
	public void add(Mailbox mailbox) {
		if(!inMailBoxes(mailbox)) mailboxes.add(mailbox);
	}
	
	/**
	 * Save a message
	 * @param text message to be saved
	 */
	public void saveMessage(String text) {
		mailboxes.get(current).saveMessage(text);
	}
	
	/**
	 * Transit method passing the task to current mailbox
	 * @param speaker to display messages
	 */
	public void playMessages(JTextArea speaker) {
		if(current >= 0) { // current mailbox selected
			mailboxes.get(current).playMessages(speaker);
		} else { // no current mailbox selected
			speaker.setText("Error: invalide mailbox number " + current);
		}
	}
}
