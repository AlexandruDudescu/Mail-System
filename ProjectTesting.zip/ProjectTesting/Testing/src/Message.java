
/**
 * A single voice message
 * @author Wei Li
 * @date January 14, 2017
 */
public class Message {
	private String message;
	
	Message(String message) {
		this.message = message;
	}
	
	public String getMessage() {
		return message;
	}
	
	public void setMessage(String newMessage) {
		message = newMessage;
	}
}
