import java.util.ArrayList;

import javax.swing.JTextArea;
/**
 * Storage suport for multiple voice messages
 * @author Wei Li
 * @date January 17, 2017
 */
		
public class Messages {
	private ArrayList<Message> messages; // stores multiple messages
	
	Messages() {
		messages = new ArrayList<Message>();
	}
	
	/**
	 * Save a message
	 * @param text message to be saved
	 */
	public void saveMessage(String text) {
		messages.add(new Message(text));
		printMessages(); // show message in another view (console)
	}
	
	/**
	 * To display messages in speaker
	 * @param speaker
	 */
	public void playMessages(JTextArea speaker) {
		speaker.setText("");  // clear speaker
		if(messages.size() == 0) {
			speaker.setText("No saved messages\n");
		}
		for(int i=0; i<messages.size(); i++) { // display messages one at a time
			if(i == 0) speaker.append("Message#"+(i+1)+":\n"); // first message does not have a leading empty line
			else speaker.append("\nMessage#"+(i+1)+":\n");
			speaker.append(messages.get(i).getMessage());
		}
		speaker.append("\n----------------\nYou can leave a message\n");
	}
	
	/**
	 * Helper method for debugging
	 * Print out all messages in the storage to console
	 */
	private void printMessages() {
		System.out.println("In messages: ");
		for(int i=0; i<messages.size(); i++) {
			System.out.println("\nMessage#"+i+":");
			System.out.print(messages.get(i).getMessage());
		}
		System.out.println();
	}
}
