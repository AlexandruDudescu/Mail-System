import javax.swing.JTextArea;

/**
 * Bridging class for UI and Voice Mail System
 * Manages four system states
 * 
 * @author Wei Li
 * @date: January 14, 2017
 */
public class Telephone {
	private VoiceMailSystem vms; // one end of the bridge
	private int vmsIndex;  // for future expansion to multiple systems
	private VMSState state; // current state
	
	// system states
	private enum VMSState {INITIAL, VERIFY_MAIN_NUMBER, MAIN_NUMBER_VERIFIED, EXTENSION_VERIFIED};
	// speeches to UI at various states
	private final String INITIAL_SPEECH = "System is ready\nPlease enter voice mail system number (10 digits)";
	private final String VMN_SPEECH = "Please enter a mail box extension number (4 digits)";
	private final String MNV_SPEECH = "Please leave a message or play saved messages\n";
	private final String EV_SPEECH = "Message saved, good bye.\nSystem is off";
	private final String VMN_ERROR = "Error: Invalid main number\nPlease try again";
	private final String MNV_ERROR = "Error: Invalid extension number\nPlease try again";
	
	Telephone(VoiceMailSystem vms) {
		this.vms = vms;
		state = VMSState.INITIAL;
	}
	/**
	 * Process text from UI based on current state
	 * @param text text to be processed
	 * @return speech
	 *
	 */
	public String processText(String text) {
		String speech = null;
		switch(state) {
		case INITIAL:
			state = VMSState.VERIFY_MAIN_NUMBER;
			speech = INITIAL_SPEECH;
			break;
		case VERIFY_MAIN_NUMBER:
			if(verifyMainNumber(text)) {
				state = VMSState.MAIN_NUMBER_VERIFIED;
				speech = VMN_SPEECH;
			} else speech = VMN_ERROR;
			break;
		case MAIN_NUMBER_VERIFIED:
			if(verifyExtension(text)) {
				state = VMSState.EXTENSION_VERIFIED;
				speech = MNV_SPEECH;
			} else speech = MNV_ERROR;
			break;
		case EXTENSION_VERIFIED:
			if(!text.equals("")) {
				saveMessage(text);
				state = VMSState.INITIAL;
				speech = EV_SPEECH;
			}
			break;
		}
		return speech;
	}
	
	/**
	 * Verify text as main number
	 * @param mainNumber
	 * @return true if mainNumber is matched with a system; false otherwise;
	 */
	public boolean verifyMainNumber(String mainNumber) {
		// filter out no-digits
		String pureNumber = mainNumber.replaceAll("[^0-9]", "");
		vmsIndex = vms.checkMainNumber(pureNumber); // save index of the current system, not used in this design
		if(vmsIndex >= 0) return true; // main number is matched
		else return false; // no match
	}
	
	/**
	 * Verify text as extension
	 * @param extension extension be verified
	 * @return true if extension matches a mailbox; false otherwise
	 */
	public boolean verifyExtension(String extension) {
		return vms.checkExtension(extension);
	}
	
	/**
	 * Save a message to the current mailbox
	 * @param text message to be saved
	 */
	public void saveMessage(String text) {
		vms.saveMessage(text);
	}
	
	/**
	 * Transit method passing the task to vms
	 * @param speaker to display messages
	 */
	public void playMessages(JTextArea speaker) {
		vms.playMessages(speaker);
	}
	
	
	public String playMessage() {
		return "Hello";
	}
	
	/**
	 * Reset system state to INITIAL
	 */
	public void hangUp() {
		state = VMSState.INITIAL;	
	}
	
	public VMSState getState() {return state;}
	
	public boolean isEVState() {
		if(state == VMSState.EXTENSION_VERIFIED) return true;
		else return false;
	}
	
	public void setInitialState() { 
		state = VMSState.INITIAL; 
	}
	
}
