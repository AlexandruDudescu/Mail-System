import java.awt.GridLayout;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;

/**
 * Graphic User Interface for Voice Mail System
 * Three panels: buttonPanel, textPanel, and labelPanel
 * Four buttons: hangUpButton, startButton, saveButton, sendButton
 * @author Wei Li
 * @date January 14, 2017
 *
 */
public class UI {
	private final float BUTTON_FONT_SIZE = 18f;
	private final float LABEL_FONT_SIZE = 24f;
	private final float TEXTAREA_FONT_SIZE = 24f;
	private final int TEXTPANEL_TITLE_FONT_SIZE = 20;
	// system window
	private JFrame frame = new JFrame("Voice Mail System - UI Prototype");
	private JPanel buttonPanel = new JPanel();
	private JButton sendButton = new JButton("Send");
	private JButton hangUpButton = new JButton("Hang Up");
	private JButton startButton = new JButton("Start");
	private JButton saveButton = new JButton("Save");
	private JButton playButton = new JButton("Play");
	private JTextArea speaker = new JTextArea(5, 10);
	private JTextArea microphone = new JTextArea(5, 10);
	private JPanel textPanel = new JPanel();
	private JPanel labelPanel = new JPanel();
	private JScrollPane speakerScroller = new JScrollPane(speaker);
	private JScrollPane microphoneScroller = new JScrollPane(microphone);
	private JLabel sLabel = new JLabel("Speaker");
	private JLabel mLabel = new JLabel("Microphone");
	
	UI(Telephone telephone) { // constructor
		// attach action listeners to buttons
		startButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				telephone.setInitialState();
				String text = telephone.processText(""); // at initial state, text does not matter
				speaker.setText(text); // show speech
				microphone.setText("");
			}
		});
		sendButton.addActionListener(new ActionListener() { 
			// text from microphone sent to telephone
			public void actionPerformed(ActionEvent event) {
				String text = microphone.getText();
				if(text.equals("")) return; // safeguard against random button click
				microphone.setText("");
				String speech = telephone.processText(text);
				speaker.setText(speech); // show speech
			}
		});
		saveButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				if(!telephone.isEVState()) return; // safeguard against random button click
				String text = microphone.getText();
				if(text.equals("")) return;
				speaker.setText(telephone.processText(text)); // show speech
				telephone.hangUp(); // turn system off
				microphone.setText("");
			}
		});
		hangUpButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				saveButton.doClick(); // save message if any
				speaker.setText("System is off\n");
			}
		});
		playButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				if(telephone.isEVState()) {
					telephone.playMessages(speaker); // law of demeter
				}
			}
		});
		// add components
		speaker.setEditable(false);
		speaker.setLineWrap(true);
		speaker.setFont(speaker.getFont().deriveFont(TEXTAREA_FONT_SIZE)); 
		microphone.setLineWrap(true);
		microphone.setFont(microphone.getFont().deriveFont(TEXTAREA_FONT_SIZE)); 
		GridLayout gl = new GridLayout();
		gl.setHgap(3);
		gl.setVgap(3);
		buttonPanel.setLayout(gl);
		hangUpButton.setFont(hangUpButton.getFont().deriveFont(BUTTON_FONT_SIZE));
		startButton.setFont(startButton.getFont().deriveFont(BUTTON_FONT_SIZE));
		saveButton.setFont(saveButton.getFont().deriveFont(BUTTON_FONT_SIZE));
		playButton.setFont(playButton.getFont().deriveFont(BUTTON_FONT_SIZE));
		sendButton.setFont(sendButton.getFont().deriveFont(BUTTON_FONT_SIZE));	
		buttonPanel.add(hangUpButton);
		buttonPanel.add(startButton);
		buttonPanel.add(saveButton);
		buttonPanel.add(playButton);
		buttonPanel.add(sendButton);
		buttonPanel.setBackground(Color.lightGray);
		buttonPanel.setBorder(new EmptyBorder(10,7,10,7));

		GridLayout gridLayout = new GridLayout(1, 2, 50, 50);
		gridLayout.setHgap(10);
		gridLayout.setVgap(10);
		labelPanel.setLayout(gridLayout);
		sLabel.setFont(sLabel.getFont().deriveFont(LABEL_FONT_SIZE));
		mLabel.setFont(mLabel.getFont().deriveFont(LABEL_FONT_SIZE));
		labelPanel.add(sLabel);
		labelPanel.add(mLabel);
	
		speaker.setBackground(Color.cyan);
		speaker.setBorder(BorderFactory.createBevelBorder(1));
		speakerScroller.setHorizontalScrollBarPolicy(
				   JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		speakerScroller.setVerticalScrollBarPolicy(
				   JScrollPane.VERTICAL_SCROLLBAR_ALWAYS); 
		microphone.setBackground(Color.green);
		
		microphoneScroller.setBorder(BorderFactory.createBevelBorder(1));
		microphoneScroller.setHorizontalScrollBarPolicy(
				   JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		microphoneScroller.setVerticalScrollBarPolicy(
				   JScrollPane.VERTICAL_SCROLLBAR_ALWAYS); 
		
		textPanel.setBorder(new EmptyBorder(10,10,10,10));
		
		/*
		TitledBorder textPanelBorder = new TitledBorder("Speaker   	        Microphone");
		textPanelBorder.setTitleFont(new Font("Arial", Font.PLAIN, TEXTPANEL_TITLE_FONT_SIZE));
		textPanelBorder.setTitleJustification(TitledBorder.CENTER);
		textPanelBorder.setTitlePosition(TitledBorder.TOP);
		textPanel.setBorder(textPanelBorder);
		*/
		
		
		textPanel.setLayout(gridLayout);
		textPanel.add(speakerScroller);
		textPanel.add(microphoneScroller);

		frame.setSize(1200, 600);
		frame.add(buttonPanel, BorderLayout.NORTH);
		frame.add(textPanel, BorderLayout.CENTER);
		frame.add(labelPanel, BorderLayout.SOUTH);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
}
