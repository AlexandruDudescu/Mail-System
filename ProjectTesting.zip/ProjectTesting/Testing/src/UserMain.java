
public class UserMain {
	public static void main(String[] args) {
		VoiceMailSystem vms = new VoiceMailSystem("2568241234");
		Telephone telephone = new Telephone(vms);
		vms.add(new Mailbox("1111"));
		UI ui = new UI(telephone);
	}
}
