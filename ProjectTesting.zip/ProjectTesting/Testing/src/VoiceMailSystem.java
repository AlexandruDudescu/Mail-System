import javax.swing.JTextArea;

/**
 * The core and only class of the system that interacts with Telephone
 * @author Wei Li
 * @date January 14, 2017
 */
public class VoiceMailSystem {
	private String mainNumber; // identify this system
	private Mailboxes mailboxes; // multiple mailboxes in a system
	
	VoiceMailSystem() {
		mailboxes = new Mailboxes();
	}
	
	VoiceMailSystem(Mailboxes mailboxes) {
		this.mailboxes = mailboxes;
	}
	
	VoiceMailSystem(String mainNumber) {
		this.mainNumber = mainNumber;
		mailboxes = new Mailboxes();
	}
	
	/**
	 * Verify the extension number
	 * @param extension extension number to be verified
	 * @return true if verified; false otherwise;
	 * @precondition extension != null
	 */
	public boolean checkExtension(String extension) {	
		return mailboxes.findCurrentMailBox(extension);
	}
	
	/**
	 * Verify the system (main) number
	 * @param number system number to be verified
	 * @return true if verified; false otherwise
	 */
	public int checkMainNumber(String number) {
		if(mainNumber.equals(number)) return 0;
		return -1;
	}
	
	/**
	 * Add a mailbox to mailboxes
	 * @param mailbox to be added
	 * @precondition mailbox != null
	 */
	public void add(Mailbox mailbox) {
		if(mailbox != null) mailboxes.add(mailbox);
	}
	
	/**
	 * Save a message
	 * @param text message to be saved
	 */
	public void saveMessage(String text) {
		mailboxes.saveMessage(text);
	}
	
	/**
	 * Transit method passing the task to mailboxes
	 * @param speaker to display messages
	 */
	public void playMessages(JTextArea speaker) {
		mailboxes.playMessages(speaker);
	}
}
